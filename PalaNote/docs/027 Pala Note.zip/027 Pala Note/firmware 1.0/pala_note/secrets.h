#ifndef SECRETS_H
#define SECRETS_H

#define WIFI_SSID   "...."
#define WIFI_PASS   "...."
#define OPENAI_KEY  "...."

#endif
